# Hospital-Management-App
This is a basic android application with firebase user authentication aiming to facilitate one to one connection of the patients with the doctor, the patient can directly discuss
their symptoms directly with a doctor which they can choose from various options from a custom list adapter. HTTP requests were handled by Volley API. Different animations like 
splash screen are used to make the application interactive.
